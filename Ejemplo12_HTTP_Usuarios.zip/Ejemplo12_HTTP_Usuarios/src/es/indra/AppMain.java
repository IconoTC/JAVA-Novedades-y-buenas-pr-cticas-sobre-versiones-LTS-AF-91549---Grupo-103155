package es.indra;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Contenedor cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		// Enviamos la peticion a traves del contenedor cliente y recibimos la respuesta
		HttpResponse<String> respuesta =  cliente.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		// Crear un array de objetos JSON
		JSONArray jsonArray = new JSONArray(respuesta.body());
		
		for (Object object : jsonArray) {
			JSONObject jsonObject = new JSONObject(object.toString());
			//System.out.println(jsonObject);
			
			// Mostrar los datos del usuario
			System.out.println("ID: " + jsonObject.getInt("id"));
			System.out.println("Nombre: " + jsonObject.getString("name"));
			System.out.println("Username: " + jsonObject.getString("username"));
			System.out.println("Email: " + jsonObject.getString("email"));
			
			JSONObject jsonDireccion = jsonObject.getJSONObject("address");
			System.out.println("Calle: " + jsonDireccion.getString("street"));
			System.out.println("Numero: " + jsonDireccion.getString("suite"));
			System.out.println("Ciudad: " + jsonDireccion.getString("city"));
			System.out.println("Codigo Postal: " + jsonDireccion.getString("zipcode"));
			
			JSONObject jsonCoordenadas = jsonDireccion.getJSONObject("geo");
			System.out.println("Latitud: " + jsonCoordenadas.getString("lat"));
			System.out.println("Longitud: " + jsonCoordenadas.getString("lng"));
			
			System.out.println("Telefono: " + jsonObject.getString("phone"));
			System.out.println("Sitio Web: " + jsonObject.getString("website"));
			
			JSONObject jsonCompany = jsonObject.getJSONObject("company");
			System.out.println("Nombre empresa: " + jsonCompany.getString("name"));
			System.out.println("Eslogan: " + jsonCompany.getString("catchPhrase"));
			System.out.println("Linea de negocio: " + jsonCompany.getString("bs"));
				
			System.out.println("----------------------------------");
		}

	}

}
