package es.indra;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class Practica {

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		// Mostrar la lista de los primeros 20 pokemons

		// Solicitar el nombre del pokemon por teclado
		// Mostrar la informacion simple y por lo menos "abilities"
		
		String url = "https://pokeapi.co/api/v2/pokemon/";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Contenedor cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		// Enviamos la peticion a traves del contenedor cliente y recibimos la respuesta
		HttpResponse<String> respuesta =  cliente.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		JSONObject jsonObject = new JSONObject(respuesta.body());
		JSONArray jsonArray = jsonObject.getJSONArray("results");
		
		System.out.println("--------- Lista de Pokemons ---------");
		for (Object object : jsonArray) {
			JSONObject jsonPokemon = new JSONObject(object.toString());
			System.out.println(jsonPokemon.getString("name"));
		}
		
		System.out.println("--------- Buscar Pokemons ---------");
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el nombre del pokemon: ");
		String nombre = sc.next();
		
		uri = new URI(url + nombre);
		request = HttpRequest.newBuilder(uri).GET().build();
		respuesta =  cliente.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		JSONObject jsonPokemon = new JSONObject(respuesta.body());
		
		// Mostrar los datos simples
		System.out.println("ID: " + jsonPokemon.getInt("id"));
		System.out.println("Nombre: " + jsonPokemon.getString("name"));
		System.out.println("Orden: " + jsonPokemon.getInt("order"));
		System.out.println("Peso: " + jsonPokemon.getInt("weight"));
		System.out.println("Altura: " + jsonPokemon.getInt("height"));
		
		
		// Mostrar "abilities"
		System.out.println("Habilidades: ");
		JSONArray jsonHabilidades = jsonPokemon.getJSONArray("abilities");
		for (Object object : jsonHabilidades) {
			JSONObject jsonHabilidad = new JSONObject(object.toString());
			JSONObject habilidad = jsonHabilidad.getJSONObject("ability");
			System.out.print(habilidad.getString("name") + " ");
		}
		
	}

}
