package es.indra;

import java.util.Optional;

public class Ejemplo_OrElseThrow {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.ofNullable(null);
		//Optional<String> op = Optional.ofNullable("Pepito");
		
		// Si el opctional esta vacio lanzamos una excepcion
		// java.util.NoSuchElementException: No value present
		// String valor = op.orElseThrow();
		// System.out.println(valor);
		
		// Puedo elegir que excepcion quiero lanzar
		String valor = op.orElseThrow(() -> new RuntimeException("El valor es nulo"));
		System.out.println(valor);
	}

}
