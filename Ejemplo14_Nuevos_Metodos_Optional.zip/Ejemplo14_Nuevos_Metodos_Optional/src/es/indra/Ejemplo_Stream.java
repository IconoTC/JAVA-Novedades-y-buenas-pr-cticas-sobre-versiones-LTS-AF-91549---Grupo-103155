package es.indra;

import java.util.Arrays;
import java.util.Optional;

public class Ejemplo_Stream {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.of("            Hola Pepito, como estas?            ");
		
		// Crear un stream a partir del optional
		// quitar los espacios por izquierda y derecha
		// partir el texto por " "
		// Mostrar en la consola
		op.stream()
			.peek(p -> System.out.println("Procesando " + p + " --------------------------"))
			.map(texto -> texto.strip())
			.map(texto -> Arrays.stream(texto.split(" ")))
			.forEach(array -> array.forEach(System.out::println));

	}

}
