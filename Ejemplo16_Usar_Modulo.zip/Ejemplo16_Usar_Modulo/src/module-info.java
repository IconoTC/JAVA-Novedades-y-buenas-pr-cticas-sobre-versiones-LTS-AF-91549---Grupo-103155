module Ejemplo16_Usar_Modulo {
	
	// Para poder usar el modulo de otro proyecto
	// es necesario agregarlo como dependencia en el module-path
	
	// requires nombre_modulo
	requires es.indra;
}