package es.indra;

import es.indra.models.Direccion;
import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion direccion = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado = new Empleado(1, "Juan", 47000, direccion);
		
		System.out.println(empleado);

	}

}
