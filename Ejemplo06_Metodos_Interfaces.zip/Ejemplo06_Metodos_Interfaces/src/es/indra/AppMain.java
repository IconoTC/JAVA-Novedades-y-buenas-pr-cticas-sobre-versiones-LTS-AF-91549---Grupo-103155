package es.indra;

import es.indra.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Invocar al metodo estatico de la interface
		ItfzMetodos.estatico();
		
		// Invocar al metodo default de la interface
		// No es estatico, por lo tanto necesito un objeto
		ItfzMetodos implementacion = new ItfzMetodos() {
		};
		implementacion.defecto();
		
		// No tengo acceso a los metodos privados
		// implementacion.mayusculas("Hola, que tal?");
		
		System.out.println(implementacion.procesarTexto("Hola, que tal?"));

	}

}
