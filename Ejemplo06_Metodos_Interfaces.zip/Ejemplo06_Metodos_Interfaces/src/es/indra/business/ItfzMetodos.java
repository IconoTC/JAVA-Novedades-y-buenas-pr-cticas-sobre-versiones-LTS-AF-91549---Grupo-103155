package es.indra.business;

public interface ItfzMetodos {
	
	// Novedad en Java 8
	//	- Metodos estaticos
	//	- Metodos default
	
	public static void estatico() {
		System.out.println("Metodo estatico");
		// Dentro de un metodo estatico solo puedo acceder a recursos estaticos
		// defecto();
		// mayusculas("mmmmmmm");
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
		//estatico();   // si tengo acceso a los recursos estaticos
	}
	
	
	// Novedad en Java 9
	//	- Metodos privados (sin static, ni default)
	
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	// La unica forma de acceder a los metodos privados
	// es desde los metodos default
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto);
	}

}
