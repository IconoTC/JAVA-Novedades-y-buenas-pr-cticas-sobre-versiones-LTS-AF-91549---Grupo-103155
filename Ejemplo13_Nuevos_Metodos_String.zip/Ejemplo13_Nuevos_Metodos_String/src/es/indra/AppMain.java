package es.indra;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		// repeat
		System.out.println("-".repeat(30));
		System.out.println("*".repeat(30));
		System.out.println("ja".repeat(15));
		
		// strip
		String nombre = "      Juan      ";
		System.out.println(nombre + ".");
		
		// Quitar espacios por izquierda y derecha
		System.out.println(nombre.strip() + ".");
		
		// Quitar espacios por izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// Quitar espacios por derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		
		// lines
		String texto = "Hola\nque\ntal?";
		System.out.println(texto);
		texto.lines()   // genera un stream con las 3 lineas del texto 
			.map(dato -> dato.toUpperCase())
			.forEach(System.out::println);

	}

}
