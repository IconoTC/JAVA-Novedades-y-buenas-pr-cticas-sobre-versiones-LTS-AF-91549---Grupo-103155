package es.indra;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// Solo funciona con variables locales
	// No se permite en propiedades o variables globales
	//var a = 125;

	public static void main(String[] args) {
		
		// Una vez que la variable ha inferido el tipo de dato, no se puede cambiar
		var dato = 64;
		//dato = "Hola";
		//dato = true;
		
		// Es obligatorio pasar un valor para que pueda inferir el tipo
		//var a;
		//var b = null;
		
		// En declaraciones multiples no funciona
		//var a,b = 56;
		//var c=8, d=17;
		
		// Declaracion multiple con tipo de dato especifico
		int a,b = 56;
		int c=8, d=17;
		
		// Con los arrays depende de como se declaren
		//var letras[] = {'a','e','i','o','u'};  NO FUNCIONA
		//var letras[] = new char[] {'a','e','i','o','u'}; NO FUNCIONA
		//var [] letras = new char[] {'a','e','i','o','u'}; NO FUNCIONA
		//var[] letras = new char[] {'a','e','i','o','u'}; NO FUNCIONA
		var letras = new char[] {'a','e','i','o','u'};
		
		// En colecciones tambien funciona con listas, set, mapas
		var lista = new ArrayList<>();  // Lista de objetos
		var lista2 = new ArrayList<String>(); // Lista de cadenas de texto 
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); // Lista de numeros enteros
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5)); // Lista de numeros enteros
		
		// El uso de inferencia de tipos en bucles tambien funciona
		for (var numero : lista4) {
			System.out.println(numero);
		}
		
		for(var i=0; i<letras.length; i++) {
			System.out.println(letras[i]);
		}
			
	}

}
