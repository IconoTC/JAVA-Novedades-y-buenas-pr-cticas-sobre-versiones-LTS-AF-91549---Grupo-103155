package es.indra;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import es.indra.models.Alumno;
import es.indra.utils.ComparadorNota;

public class AppMain {

	public static void main(String[] args) {
		
		//Set<Alumno> alumnos = new TreeSet<Alumno>(new ComparadorNota());
		Set<Alumno> alumnos = new TreeSet<Alumno>( (alum1, alum2) -> alum1.getNombre().compareTo(alum2.getNombre()) );
		
		// Agregar 5 alumnos
		alumnos.add(new Alumno(1, "Juan", "Perez", 'H', 7.5, false));
		alumnos.add(new Alumno(2, "Maria", "Sanchez", 'M', 4.2, true));
		alumnos.add(new Alumno(3, "Pedro", "Gonzalez", 'H', 9.2, false));
		alumnos.add(new Alumno(4, "Luis", "Rodriguez", 'H', 10, false));
		alumnos.add(new Alumno(5, "Sara", "Garcia", 'M', 10, true));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("---------------------------------");
		
		// Generar una lista a partir del arbol de alumnos
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);
		
		// Clasificar la lista por apellido ascendente
		lista.sort( (Alumno alum1, Alumno alum2) -> alum1.getApellido().compareTo(alum2.getApellido()) );
		//lista.forEach(System.out::println);  // Invocacion estatica en Java 8
		lista.forEach(alumno -> System.out.println(alumno));
		System.out.println("---------------------------------");
		
		// Clasificar la lista por apellido descendente
		lista.sort( (Alumno alum1, Alumno alum2) -> alum2.getApellido().compareTo(alum1.getApellido()) );
		lista.forEach(System.out::println);  
		System.out.println("---------------------------------");
		
		// Clasificar la lista por numAlumno ascendente
		lista.sort( (Alumno alum1, Alumno alum2) -> alum1.getNumAlumno() - alum2.getNumAlumno() );
		lista.forEach(System.out::println);  
		System.out.println("---------------------------------");
		
		// Clasificar la lista por numAlumno descendente
		lista.sort( (Alumno alum1, Alumno alum2) -> alum2.getNumAlumno() - alum1.getNumAlumno() );
		lista.forEach(System.out::println);  
		System.out.println("---------------------------------");
		
		// Clasificar la lista por nota ascendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota));
		lista.forEach(System.out::println);  
		System.out.println("---------------------------------");
		
		// Clasificar la lista por nota descendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota).reversed());
		lista.forEach(System.out::println);  
		System.out.println("---------------------------------");

	}

}
