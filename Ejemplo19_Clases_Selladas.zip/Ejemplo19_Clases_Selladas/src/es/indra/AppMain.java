package es.indra;

import es.indra.models.Circulo;
import es.indra.models.Elipse;
import es.indra.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo(4.12);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		Rectangulo rectangulo = new Rectangulo(20, 10);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		Elipse elipse = new Elipse(20, 10);
		System.out.println("Area de la elipse: " + elipse.calcularArea());

	}

}
