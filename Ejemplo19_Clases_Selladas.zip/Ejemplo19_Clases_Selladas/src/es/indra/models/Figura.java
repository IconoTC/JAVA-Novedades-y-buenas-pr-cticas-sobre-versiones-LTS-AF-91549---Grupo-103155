package es.indra.models;

// Una clase sellada controla que subclase tiene permiso para heredar de ella
public sealed abstract class Figura permits Circulo, Rectangulo {
	
	public abstract double calcularArea();

}
