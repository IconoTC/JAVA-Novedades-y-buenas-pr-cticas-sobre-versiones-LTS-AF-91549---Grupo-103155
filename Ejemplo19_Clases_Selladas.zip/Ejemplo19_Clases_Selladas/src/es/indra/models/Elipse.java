package es.indra.models;

//Ahora la clase Elipse debe declararse de una de estas formas:
//	1.- final -> Ya no se puede heredar de ella
//	2.- non-sealed -> Hemos quitado el sellado, cualquier clase puede heredar de Elipse
//	3.- sealed -> Sigue siendo una clase sellada y tendremos que indicar que subclases 
//            tienen permiso para heredar de ella
public non-sealed class Elipse extends Rectangulo {

	public Elipse() {
		// TODO Auto-generated constructor stub
	}

	public Elipse(double base, double altura) {
		super(base, altura);
	}

	@Override
	public double calcularArea() {
		// PI x altura x base
		return Math.PI * getAltura() * getBase();
	}

	@Override
	public String toString() {
		return "Elipse [base=" + getBase() + ", altura=" + getAltura() + "]";
	}

}
