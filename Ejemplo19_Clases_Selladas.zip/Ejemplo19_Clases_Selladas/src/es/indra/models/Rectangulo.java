package es.indra.models;

//Ahora la clase Rectangulo debe declararse de una de estas formas:
//	1.- final -> Ya no se puede heredar de ella
//	2.- non-sealed -> Hemos quitado el sellado, cualquier clase puede heredar de Rectangulo
//	3.- sealed -> Sigue siendo una clase sellada y tendremos que indicar que subclases 
//                tienen permiso para heredar de ella
public sealed class Rectangulo extends Figura permits Elipse{

	private double base;
	private double altura;

	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	public Rectangulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		return base * altura;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + "]";
	}

}
