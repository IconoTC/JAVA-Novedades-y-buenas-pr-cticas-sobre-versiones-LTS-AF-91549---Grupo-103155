package es.indra.business;

// Una interface funcional tine SOLO un metodo abstracto

@FunctionalInterface
public interface ItfzFuncional {

	String infoPersonas(String nombre, int edad);
	
}
