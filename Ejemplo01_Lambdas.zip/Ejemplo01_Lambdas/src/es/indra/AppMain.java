package es.indra;

import es.indra.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis: parametros -> cuerpo de la funcion
		
		// Al ser 2 parametros es obligatorio usar parentesis
		// Los nombres de los parametros no tienen porque llamarse igual
		// No es obligatorio poner el tipo de los parametros
		// Si el cuerpo de la funcion es una sola linea no se necesitan las {} y hay un return implicito
		ItfzFuncional lambda1 = (n,e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 25));
		
		
		// Si pongo el tipo de dato del parametro es obligatorio usar pantentesis ()
		// Si opto por poner el tipo de dato, todos los parametros o ninguno
		ItfzFuncional lambda2 = (String n, int e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda2.infoPersonas("Pepito", 25));
	
		
		// Si quiero poner el return, aunque sea solo una linea hay que poner {}
		ItfzFuncional lambda3 = (n,e) -> {
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 25));
		
		
		// Si el cuerpo tiene varias lineas, se necesitan {}
		// Si utilizas llaves hay que poner el return
		ItfzFuncional lambda4 = (n,e) -> {
			e++;
			n = n.toUpperCase();
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 25));
		
		
		// Los lambdas tambien soportan la inferencia de tipos
		// var en todos los parametros o ninguno
		ItfzFuncional lambda5 = (var n, var e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda5.infoPersonas("Pepito", 25));

	}

}
