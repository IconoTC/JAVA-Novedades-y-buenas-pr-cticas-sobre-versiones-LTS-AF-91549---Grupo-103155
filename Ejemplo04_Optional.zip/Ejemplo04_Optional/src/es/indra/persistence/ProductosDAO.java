package es.indra.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import es.indra.models.Producto;

public class ProductosDAO {
	
	private List<Producto> lista = Arrays.asList(
		new Producto(1, "Pantalla", 129.95),
		new Producto(2, "Teclado", 37.5),
		new Producto(3, "Raton", 18.75),
		new Producto(4, "Impresora", 89.90),
		new Producto(5, "Scanner", 300)
	);
	
	public Optional<Producto>  buscarProducto(int id_producto){
		
		// Version 1
		for (Producto producto : lista) {
			if (id_producto == producto.getID()) {
				// Crear un optional con ese producto y lo retorno
				return Optional.of(producto);
			}
		}
		return Optional.empty();
		
		
		// Version
//		return lista.stream()
//				.filter(prod -> id_producto == prod.getID())
//				.findFirst();
	}

}
