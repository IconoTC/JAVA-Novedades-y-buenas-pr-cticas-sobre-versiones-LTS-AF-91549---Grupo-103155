package es.indra;

import java.util.Optional;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto que existe
		System.out.println(dao.buscarProducto(3)); // Optional<Producto>
		System.out.println(dao.buscarProducto(3).get()); // Producto
		
		// Buscar un producto que NO existe
		System.out.println(dao.buscarProducto(35445)); // Optional.empty
		// System.out.println(dao.buscarProducto(38766).get()); // java.util.NoSuchElementException: No value present
		
		// 1ª forma de evitar la excepcion
		System.out.println(dao.buscarProducto(38766).orElse(new Producto())  );
		
		// 2ª forma de evitar la excepcion
		Optional<Producto> opProducto = dao.buscarProducto(35445);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Ese producto no existe");
		}
		
		// 3ª forma de evitar la excepcion
		opProducto = dao.buscarProducto(35445);
		if (opProducto.isEmpty()) {			
			System.out.println("Ese producto no existe");
		} else {
			System.out.println(opProducto.get());
		}
	}

}
