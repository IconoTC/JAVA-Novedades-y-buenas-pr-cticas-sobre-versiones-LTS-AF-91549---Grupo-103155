package es.indra;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Escribir_Fichero {

	public static void main(String[] args) {
		
		// try con recursos
		// Los recuros que se abren dentro de los parentesis del bloque try
		// y ademas son AutoCloseables, se cieran solos
		// No es necesario llamar al metodo close()
		try (FileWriter fichero = new FileWriter("datos.txt");
			 	BufferedWriter bw = new BufferedWriter(fichero); ){
			
			// Escribir contenido en el fichero
			bw.write("Hola");
			bw.write("\n");
			bw.write("que tal?\n");
			bw.write("Mañana es viernes");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
