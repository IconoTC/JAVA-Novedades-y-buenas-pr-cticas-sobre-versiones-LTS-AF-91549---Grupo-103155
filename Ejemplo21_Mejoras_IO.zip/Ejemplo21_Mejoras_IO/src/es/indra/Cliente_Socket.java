package es.indra;

import java.io.ObjectOutputStream;
import java.net.Socket;

public class Cliente_Socket {

	public static void main(String[] args) {
		
		String host = "localhost";
		int puerto = 32915;
		
		try (Socket socket = new Socket(host, puerto);
				ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());) {
			
			// Enviamos un mensaje
			oos.writeObject("Hola, esto es una prueba de sockets");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
