package es.indra;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import es.indra.models.Empleado;

public class Deserializar_Objetos {

	public static void main(String[] args) {
		
		try (FileInputStream fichero = new FileInputStream("empleado.ser");
				ObjectInputStream inputStream = new ObjectInputStream(fichero)) {
			
			// Deserializar el objeto y mostrarlo
			Empleado empleado = (Empleado) inputStream.readObject();
			System.out.println(empleado);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
