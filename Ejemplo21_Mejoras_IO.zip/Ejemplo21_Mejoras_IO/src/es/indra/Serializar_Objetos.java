package es.indra;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import es.indra.models.Direccion;
import es.indra.models.Empleado;

public class Serializar_Objetos {

	public static void main(String[] args) {
		
		Empleado empleado = new Empleado(1, "Juan", 47_000, 
				new Direccion("Mayor", 5, "Madrid"));
		
		try (FileOutputStream fichero = new FileOutputStream("empleado.ser");
				ObjectOutputStream outputStream = new ObjectOutputStream(fichero)) {
			
			// Serializar el objeto
			outputStream.writeObject(empleado);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
