package es.indra;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

public class Descomprimir_Fichero {

	public static void main(String[] args) {
		
		try (FileInputStream fichero = new FileInputStream("comprimido.zip");
				GZIPInputStream gzip = new GZIPInputStream(fichero);
				BufferedReader bReader = new BufferedReader(new InputStreamReader(gzip))) {
			
			// Descomprimir el fichero, leerlo y mostrar el resultado
			bReader.lines()
				.forEach(System.out::println);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
