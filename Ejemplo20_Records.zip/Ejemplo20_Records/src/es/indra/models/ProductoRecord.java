package es.indra.models;

/*
 * Patrón de Data Classes: crear clases de datos simples y fácilmente serializables
 * */


// Un record es otra forma de crear clases de objetos
// Genera de forma automatica:
//		constructor completo
//      los metodos de acceso pero no son getDescripcion() sino descripcion()
//      toString
//      equals() y hascode() 
public record ProductoRecord(
		int ID,
		String descripcion,
		double precio
) {}


