package es.indra;

import es.indra.models.Producto;
import es.indra.models.ProductoRecord;

public class AppMain {

	public static void main(String[] args) {
		
		Producto p1 = new Producto();
		Producto p2 = new Producto(1, "Pantalla", 240);
		
		//ProductoRecord p3 = new ProductoRecord();
		ProductoRecord p3 = new ProductoRecord(2, "Teclado", 55.90);
		ProductoRecord p4 = new ProductoRecord(2, "Teclado", 55.90);
		
		System.out.println(p1);
		System.out.println(p2);
		//System.out.println(p3);
		System.out.println(p4);
		
		System.out.println("Descripcion: " + p4.descripcion());
		
		// Los campos declarados en un record son implicitamente finales (constantes)
		//p4.precio(60);
		//p4.precio = 60;
		
		System.out.println("Son iguales? " + p3.equals(p4));
		System.out.println("Mismo hashCode? " + (p3.hashCode() == p4.hashCode()) );

	}

}
