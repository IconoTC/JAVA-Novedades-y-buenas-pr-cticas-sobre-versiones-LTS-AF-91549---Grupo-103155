package es.indra;

import java.util.concurrent.CompletableFuture;

public class MostrarNumeros {

	public static void main(String[] args) throws InterruptedException {
		
		CompletableFuture<Void> tarea = CompletableFuture.runAsync(() -> {
			// Implementacion del metodo run de la interface Runnable
			// Todo el codigo que escribimos aqui se ejecuta en un hilo aparte
			for (int i=1; i<=10; i++) {
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Tarea asincrona " + i);
			}
		});
		
		// Espera a terminar la tarea y muestra el resultado final
		tarea.thenRun(() -> System.out.println("Tarea finalizada"));
		
		// El hilo principal (metodo main) finaliza antes que la tarea asincrona
		// Paramos el hilo principal, le da tiempo a recibir los datos
		Thread.sleep(5000);

	}

}
