package es.indra;

import java.util.concurrent.CompletableFuture;

public class ObtenerDatos {

	public static void main(String[] args) {
		
		// Lo ejecuto de forma sincrona
		//String resultado = new ObtenerDatos().consultaBBDD();
		//System.out.println(resultado);
				
		// Lo ejecuto de forma asincrona
		CompletableFuture<String> tarea = CompletableFuture.supplyAsync( 
				() -> new ObtenerDatos().consultaBBDD()
		);
		
		String resultado = tarea.join();
		System.out.println(resultado);
		//tarea.thenAccept(resultado -> System.out.println(resultado));
		System.out.println("----- FIN -----");
	}
	
	
	public  String consultaBBDD()  {
		// Simular una peticion lenta a la BBDD
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Datos leidos";
	}

}
