package es.indra;

import java.util.concurrent.CompletableFuture;

public class EncadenarTextos {

	public static void main(String[] args) {
		
		CompletableFuture.supplyAsync(() -> "Hola")
			.thenApply(resultado -> resultado + " que tal?")
			.thenAcceptAsync(System.out::println)
			.join();

	}

}
