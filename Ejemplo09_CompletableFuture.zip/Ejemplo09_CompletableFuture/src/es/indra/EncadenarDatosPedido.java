package es.indra;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public class EncadenarDatosPedido {

		public static void main(String[] args) {
			CompletableFuture<String> resultado = obtenerPedido(123)
					.thenCompose(pedido -> obtenerCliente(pedido))
					.thenApply(cliente -> cliente.toUpperCase())
					.thenApply(cliente -> "Procesando datos del Cliente: " + cliente);
			
			// Recoger y mostrar resultados
			// System.out.println(resultado.join());
			
			// Volcar la informacion en un fichero
			resultado.thenAccept(datos -> {
				try {
					Files.writeString(Path.of("resultado.txt"), datos);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}).join();
		}
		
		
		public static CompletableFuture<String> obtenerPedido(int id){
			return CompletableFuture.supplyAsync(() -> {
				System.out.println("Buscando pedido con id " + id);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return "Pedido: " + id + " detalle del pedido ";
			});
		}
		
		public static CompletableFuture<String> obtenerCliente(String pedido){
			return CompletableFuture.supplyAsync(() -> {
				System.out.println("Buscando los datos del cliente de ese pedido " + pedido);
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return "Pepito Perez";
			});
		}
	
}
