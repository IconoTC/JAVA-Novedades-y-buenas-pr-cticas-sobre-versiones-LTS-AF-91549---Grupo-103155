package es.indra;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EjemplosZoneDateTime {

	public static void main(String[] args) {
		
		// Mostrar todas las zonas horarias
		System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear una zona horaria 
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Hora actual de Madrid
		LocalTime ahora_Madrid = LocalTime.now();
		System.out.println(ahora_Madrid);
		
		// Hora actual en Nuew_York
		System.out.println(ZonedDateTime.now(USEast));
		
		// Crear fecha y hora en Madrid
		LocalDateTime madrid = LocalDateTime.of(2026, Month.DECEMBER, 10, 21, 30);
		ZonedDateTime horaSpain = ZonedDateTime.of(madrid, ZoneId.of("Europe/Madrid"));
		System.out.println("Hora en España: " + horaSpain);
		
		// Convertir esa fecha y hora de Madrid en fecha y hora New York
		ZonedDateTime horaNewYork = ZonedDateTime.of(madrid, USEast);
		System.out.println("Hora en New York: " + horaNewYork);

	}

}
