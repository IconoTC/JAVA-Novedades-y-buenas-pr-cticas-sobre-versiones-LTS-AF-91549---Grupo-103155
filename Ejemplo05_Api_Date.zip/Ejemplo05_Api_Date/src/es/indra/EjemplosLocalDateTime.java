package es.indra;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemplosLocalDateTime {

	public static void main(String[] args) {
		
		// El vuelo es el 10 de Diciembre de 2026 a las 21:30
		LocalDateTime vuelo = LocalDateTime.of(2026, Month.DECEMBER, 10, 21, 30);
		System.out.println(vuelo);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2026, Month.DECEMBER, 10);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime vuelo2 = LocalDateTime.of(fecha, hora);
		System.out.println(vuelo2);
		
		// Retrasar el vuelo una semana y 1 dia
		System.out.println(vuelo.plusWeeks(1).plusDays(1));
		
		// Adelantar el vuelo 1 mes
		System.out.println(vuelo.minusMonths(1));

	}

}
