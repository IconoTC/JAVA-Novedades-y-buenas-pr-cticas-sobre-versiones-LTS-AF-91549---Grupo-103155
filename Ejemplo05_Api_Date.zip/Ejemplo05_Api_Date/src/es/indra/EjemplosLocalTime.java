package es.indra;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemplosLocalTime {
	
	public static void main(String[] args) {
		
		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);
		
		// Solo horas:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));
		System.out.println(ahora.truncatedTo(ChronoUnit.HOURS));
		
		// java.time.temporal.UnsupportedTemporalTypeException: Unit is too large to be used for truncation
		//System.out.println(ahora.truncatedTo(ChronoUnit.YEARS));
		
		// Hora fin de clase
		LocalTime fin = LocalTime.of(14, 0);
		System.out.println(fin);
		
		// Cuanto nos queda de clase
		System.out.println("Nos queda " + ahora.until(fin, ChronoUnit.HOURS) + " horas");
		System.out.println("Nos queda " + ahora.until(fin, ChronoUnit.MINUTES) + " minutos");
		
		// Transformar la hora actual
		System.out.println(ahora.plusHours(10));
		System.out.println(ahora.minusHours(10));
		
		// Convertir hora a segundos
		System.out.println(ahora.toSecondOfDay() + " segundos");
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");
	}

}
