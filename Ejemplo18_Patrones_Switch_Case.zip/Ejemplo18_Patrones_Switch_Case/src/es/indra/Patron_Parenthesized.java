package es.indra;

public class Patron_Parenthesized {

	public static void main(String[] args) {
		
		var dato = "pepito@gmail.com";
		//var dato = "pepito";
		//var dato = "pepito@";
		//var dato = "pepito.";
		//var dato = "pepito.@";
		//var dato = 1234;
		
		// Solo funciona a partir de Java 21
		String mensaje = switch (dato) {
			case String email when (email.length() > 5 && email.contains("@") && email.contains(".")) -> "Email valido";
		
			default -> "Email no valido";
		};
		
		System.out.println(mensaje);

	}

}
