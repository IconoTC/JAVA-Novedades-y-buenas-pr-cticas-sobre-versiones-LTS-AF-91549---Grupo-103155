package es.indra;

public class Patron_Type {
	
	public static void main(String[] args) {
		
		// No funciona con inferencia de tipos
		// var dato = 45678;
		
		Object dato = 45678;
		//Object dato = true;
		//Object dato = 765545678L;
		//Object dato = 45678.7645433;
		//Object dato = "Hola";
		
		String formato = switch (dato) {
			case String texto -> texto.toUpperCase();
			case Integer entero -> String.format("entero %d", entero);
			case Double real -> String.format("real %.1f", real);
			case Long numLong -> String.format("long %,d", numLong);
		
			default -> dato.toString();
		};
		
		System.out.println(formato);
	}

}
