package es.indra;

public class Patron_Guarded {

	public static void main(String[] args) {
		
		// No funciona con inferencia de tipos
		//Object dato = "pepito@gmail.com";
		//Object dato = "pepito";
		//Object dato = "pepito@";
		//Object dato = "pepito.";
		//Object dato = "pepito.@";
		Object dato = 1234;
		
		// Solo funciona a partir de Java 21
		String mensaje = switch (dato) {
			case String email -> {
				if (email.length() < 5)
					yield "Email no tiene suficientes caracteres";
				else if (!email.contains("@"))
					yield "El email no contiene @";
				else if (!email.contains("."))
					yield "El email no contiene .";
				else
					yield "Email valido";			
			}
			default -> "Email no valido";
				
		};
		
		System.out.println(mensaje);

	}

}
