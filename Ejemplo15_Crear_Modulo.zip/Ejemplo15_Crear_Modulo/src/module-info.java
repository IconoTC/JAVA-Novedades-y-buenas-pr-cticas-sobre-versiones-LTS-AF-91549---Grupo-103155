module es.indra {
	
	// exports paquete
	exports es.indra.models;
}